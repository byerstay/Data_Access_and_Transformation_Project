#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 15:41:42 2020

@author: taylorbyers
"""

import pandas as pd

#CLEANING THE DATA:
#Importing the Dataset
df = pd.read_csv('Conditions_contributing_to_deaths_involving_coronavirus_disease_2019__COVID-19___by_age_group_and_state__United_States. 7.22.2020.csv')

#Previewing data
print("Preview of first 50 rows of data:")
print(df.head(50))
print("Previewing columns 'State' and 'Group':")
print(df[['State', 'Condition Group']])

#Current total missing values for each column
print("Total values missing for each column: ")
print(df.isnull().sum(),"\n")
#Replacing missing values in 'Number of COVID-19 Deaths' Column with zeros
df['Number of COVID-19 Deaths'] = df['Number of COVID-19 Deaths'].fillna(0)

#Deleting four unnecessary columns: (0) "Data as of" Date, (1) "Start Week", (2) "End Week", (9) Flag
df.drop(df.columns[[0, 1, 2, 9]], axis = 1, inplace = True) 
indexUS = df[df['State'] == 'US'].index
df.drop(indexUS, inplace=True)
indexYC = df[df['State'] == 'YC'].index
df.drop(indexYC, inplace=True)
print(df)

#Creating new dataframe for all data for all ages
df_all_ages = df[df['Age Group'] == 'All ages']
df_all_ages = df_all_ages.groupby(['Condition Group', 'State'])['Number of COVID-19 Deaths'].sum()
df_all_ages = df_all_ages.unstack(level=0)
df_all_ages.to_csv('all_ages.csv')

#Getting names of indexes for which column "Age Group" is "All Ages"
indexAges = df[df['Age Group'] == 'All ages'].index
#Deleting these row indexes from the dataframe
df.drop(indexAges, inplace=True)
df.to_csv('data_without_total.csv')

#Creating new dataframe for diseases per age
disease_by_age = df.groupby(['Condition Group', 'Age Group'])['Number of COVID-19 Deaths'].sum()
disease_by_age = disease_by_age.unstack(level=0)
disease_by_age = disease_by_age.iloc[:-2]
disease_by_age.to_csv('disease_by_age.csv')

#Creating new, separate dataframe for all condition groups
respiratory = df.loc[df['Condition Group']=='Respiratory diseases']
circulatory = df.loc[df['Condition Group']=='Circulatory diseases']
sepsis = df.loc[df['Condition Group']=='Sepsis']
neoplasms = df.loc[df['Condition Group']=='Malignant neoplasms']
alzheimers = df.loc[df['Condition Group']=='Alzheimer disease']
renal = df.loc[df['Condition Group']=='Renal failure']
diabetes = df.loc[df['Condition Group']=='Diabetes']
obesity = df.loc[df['Condition Group']=='Obesity']
vascular = df.loc[df['Condition Group']=='Vascular and unspecified dementia']
injury = df.loc[df['Condition Group']=='Intentional and unintentional injury, poisoning and other adverse events']
covid = df.loc[df['Condition Group']=='Coronavirus Disease 2019']
other = df.loc[df['Condition Group']=='All other conditions and causes (residual)']

#Exporting cleaned data to separate CSV files by dataframe
respiratory.to_csv('respiratory_cleaned.csv')
circulatory.to_csv('circulatory_cleaned.csv')
sepsis.to_csv('sepsis_cleaned.csv')
neoplasms.to_csv('neoplasms_cleaned.csv')
alzheimers.to_csv('alzheimers_cleaned.csv')
renal.to_csv('renal_cleaned.csv')
diabetes.to_csv('diabetes_cleaned.csv')
obesity.to_csv('obesity_cleaned.csv')
vascular.to_csv('vascular_cleaned.csv')
injury.to_csv('injury_cleaned.csv')
covid.to_csv('covid_cleaned.csv')
other.to_csv('other_cleaned.csv')


