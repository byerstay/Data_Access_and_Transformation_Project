#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 15:41:58 2020

@author: taylorbyers
"""


import pandas as pd
import matplotlib.pyplot as plt

#Importing All Needed Cleaned Data for Exploratory Analysis
all_ages = pd.read_csv('all_ages.csv')
without_all_ages = pd.read_csv('data_without_total.csv')
disease_by_age = pd.read_csv('disease_by_age.csv')

#ANALYZING THE DATA:
#Answering Analysis Question #1 (Outlined in Analysis Formal Report)
print("Total number of deaths across entire United States by Condition Group:")
sum_by_condition = without_all_ages.groupby('Condition Group')['Number of COVID-19 Deaths'].sum()
print(sum_by_condition)

print("\nThe health condition that was the leading cause of deaths in conjunction with the coronavirus is: ")
print(sum_by_condition[sum_by_condition == sum_by_condition.max()]) 

print("\nThe health condition that was the least cause of deaths in conjunction with the coronavirus is: ")
print(sum_by_condition[sum_by_condition == sum_by_condition.min()])

#Answering Analysis Question #2 (Outlined in Analysis Formal Report)
#Bar Graphs for each Condition Group by State
all_ages.plot(kind='bar', x='State', y='Respiratory diseases', figsize=(10,5))
plt.ylabel("Number of Cases")

all_ages.plot(kind='bar', x='State', y='All other conditions and causes (residual)', figsize=(10,5))
plt.ylabel("Number of Cases")

all_ages.plot(kind='bar', x='State', y='Alzheimer disease', figsize=(10,5))
plt.ylabel("Number of Cases")

all_ages.plot(kind='bar', x='State', y='Circulatory diseases', figsize=(10,5))
plt.ylabel("Number of Cases")

all_ages.plot(kind='bar', x='State', y='Coronavirus Disease 2019', figsize=(10,5))
plt.ylabel("Number of Cases")

all_ages.plot(kind='bar', x='State', y='Diabetes', figsize=(10,5))
plt.ylabel("Number of Cases")

all_ages.plot(kind='bar', x='State', y='Intentional and unintentional injury, poisoning and other adverse events', figsize=(10,5))
plt.ylabel("Number of Cases")

all_ages.plot(kind='bar', x='State', y='Malignant neoplasms', figsize=(10,5))
plt.ylabel("Number of Cases")

all_ages.plot(kind='bar', x='State', y='Obesity', figsize=(10,5))
plt.ylabel("Number of Cases")

all_ages.plot(kind='bar', x='State', y='Renal failure', figsize=(10,5))
plt.ylabel("Number of Cases")

all_ages.plot(kind='bar', x='State', y='Sepsis', figsize=(10,5))
plt.ylabel("Number of Cases")

all_ages.plot(kind='bar', x='State', y='Vascular and unspecified dementia', figsize=(10,5))
plt.ylabel("Number of Cases")


#Answering Analysis Question #3 (Outlined in Analysis Formal Report)
#Bar Graphs for each Condition Group by Age Group
disease_by_age.plot(kind='bar', x='Age Group', y='Respiratory diseases', figsize=(10,5))
plt.ylabel("Number of Cases")

disease_by_age.plot(kind='bar', x='Age Group', y='All other conditions and causes (residual)', figsize=(10,5))
plt.ylabel("Number of Cases")

disease_by_age.plot(kind='bar', x='Age Group', y='Alzheimer disease', figsize=(10,5))
plt.ylabel("Number of Cases")

disease_by_age.plot(kind='bar', x='Age Group', y='Circulatory diseases', figsize=(10,5))
plt.ylabel("Number of Cases")

disease_by_age.plot(kind='bar', x='Age Group', y='Coronavirus Disease 2019', figsize=(10,5))
plt.ylabel("Number of Cases")

disease_by_age.plot(kind='bar', x='Age Group', y='Diabetes', figsize=(10,5))
plt.ylabel("Number of Cases")

disease_by_age.plot(kind='bar', x='Age Group', y='Intentional and unintentional injury, poisoning and other adverse events', figsize=(10,5))
plt.ylabel("Number of Cases")

disease_by_age.plot(kind='bar', x='Age Group', y='Malignant neoplasms', figsize=(10,5))
plt.ylabel("Number of Cases")

disease_by_age.plot(kind='bar', x='Age Group', y='Obesity', figsize=(10,5))
plt.ylabel("Number of Cases")

disease_by_age.plot(kind='bar', x='Age Group', y='Renal failure', figsize=(10,5))
plt.ylabel("Number of Cases")

disease_by_age.plot(kind='bar', x='Age Group', y='Vascular and unspecified dementia', figsize=(10,5))
plt.ylabel("Number of Cases")

disease_by_age.plot(kind='bar', x='Age Group', y='Sepsis', figsize=(10,5))
plt.ylabel("Number of Cases")


