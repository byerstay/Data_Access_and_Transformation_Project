READ ME

---

STEPS TO PERFORMING DATA ACCESS AND TRANSFORMATION ON "THE ANALYSIS ON CONDITIONS CONTRIBUTING TO DEATHS INVOLVING CORONAVIRUS DISEASE 2019 IN THE UNITED STATES"

---

1. In the python_programs folder, the file covid_clean.py contains the python program that accesses the data and cleans it.

1.a. The data_raw folder, contains the raw data file obtained from the CDC website.

1.b. The data_tidy folder contains data files that are clean and produced from the covid_clean.py program.

2. In the python_programs folder, the file covid_analyze.py contains the python program that runs exploratory tests on the clean data.

2.a. Tables and figures produced from the covid_analyze.py program are stored in the output_files folder, and they answer each of the posed questions in the analysis.
